[RU]
1 - Кто говорит
2 - Что говорит
3 - Номер изображения из папки "images"

Полная документация > https://NovellEngineX.github.io/develop

[EN]
1 - Who speaks
2 - What says
3 - Picture number from the "images" folder

Full documentation > https://NovellEngineX.github.io/develop