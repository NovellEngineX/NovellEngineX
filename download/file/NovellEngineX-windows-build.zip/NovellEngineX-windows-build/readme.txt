[САЙТ ДВИЖКА]: https://NovellEngineX.github.io

[ДЛЯ РАЗРАБОТЧИКОВ]: https://NovellEngineX.github.io/develop

[ЛИЦЕНЗИОННОЕ СОГЛАШЕНИЕ]: https://NovellEngineX.github.io/license

Поддержите проект рублём! Мы будем благодарны - https://NovellEngineX.github.io/donate (Перевод от 1₽)