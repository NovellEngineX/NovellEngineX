[САЙТ ДВИЖКА]: https://NovellEngineX.github.io

[ДЛЯ РАЗРАБОТЧИКОВ]: https://NovellEngineX.github.io/develop

Поддержите проект рублём! Мы будем благодарны - https://NovellEngineX.github.io/donate (Донат от 1₽)