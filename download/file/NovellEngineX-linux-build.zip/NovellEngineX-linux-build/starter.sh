# !/bin/env bash
echo "[+] Installing mono..."
apt install mono-complete -y>/dev/null 2>&1
error_message=$(mono -V >/dev/null 2>&1 && echo "$?")
if [ $error_message==0 ]; then
echo "[+] Successfull installed"
mono NovellEngineX.app
else
echo "[-] Installing error"
fi