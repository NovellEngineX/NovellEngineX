# !/bin/env bash
first_test=$(mono -V >/dev/null 2>&1 && echo "$?")
if [ "$first_test" -eq 0 ]; then
  echo "[+] Opening project..."
  mono NovellEngineX.app
else
  echo "[+] Installing mono..."
  apt install mono-complete -y>/dev/null 2>&1
  second_test=$(mono -V >/dev/null 2>&1 && echo "$?")
    if [ "$second_test" -ne 0 ]; then
      echo "[-] Installing error"
    else
      echo "[+] Installed successful"
      mono NovellEngineX.app
  fi
fi