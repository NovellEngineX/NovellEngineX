# !/bin/env bash

check_connection_method=$(ping -c 1 8.8.8.8 >/dev/null 2>&1 || echo "$?")

apt=$(which apt)
apt_path=/usr/bin/apt

dnf=$(which dnf)
dnf_path=/ust/bin/dnf

app_name=NovellEngineX.app

find_mono=$(which mono | cut -d"/" -f4)

officall_site=https://www.mono-project.com/download/stable/

check_type_shell=$(echo $SHELL | cut -d"/" -f4)
echo "\033[33m If you find bag or get error, please, write me on telegramm - @became_you \033[33m"
if [ "$apt" = "$apt_path" ]; then
mono_first_test_apt=$(echo $find_mono)
	if [ "$mono_first_test_apt" = "mono" ]; then
		echo "\033[32m [+] Opening project...\033[32m"
		mono $app_name 
	else
		echo "\033[34m [+] Detected \033[4m apt \033[24m package manager \033[34m"
		echo "\033[34m [+] Process is starting... \033[34m"
		echo "\033[34m [+] Testing connection... \033[34m"
		connection_test_apt=$(echo "$check_connection_method")
			if [ "$connection_test_apt" -eq 2 ]; then
				echo "\033[31m [-] Error: connection refused. Network unvailable. Check your internet connection. \033[31m"
				echo "\033[31m [-] Installing error \033[31m"
			else
				echo "\033[32m [+] Connection: ok \033[32m"
				echo "\033[32m [+] Installing mono-complete, please wait...\033[32m"
				apt install apt-transport-https dirmngr gnupg ca-certificates y>/dev/null 2>&1
		   		apt-key adv --keyserver hkp://keyserver.ubuntu.com:80 --recv-keys 3FA7E0328081BFF6A14DA29AA6A19B38D3D831EF >/dev/null 2>&1
		   		echo "deb https://download.mono-project.com/repo/debian stable-stretch main" | sudo tee /etc/apt/sources.list.d/mono-official-stable.list >/dev/null 2>&1
		   		apt update -y >/dev/null 2>&1
		   		apt-get install libatk-adaptor libgail-common mono-complete -y>/dev/null 2>&1
				mono_second_test_apt=$(echo $find_mono)
				if [ "$mono_second_test_apt" != "mono" ]; then
					echo "\033[31m [-] Installing error \033[31m"
					echo "\033[36m [?] If you can not install mono-complete automatically, please visit officall site: \033[33;4m "$officall_site" \033[33;24m \033[36m"
				else
					echo "\033[32m [+] installation completed successfully \033[32m"
				fi
			fi
	fi

elif [ "$dnf" = "$dnf_path" ]; then
	echo "\033[33m If you find bag or get error, please, write me on telegramm - @became_you \033[33m"
	mono_first_test_dnf=$(echo $find_mono)
		if [ "$mono_first_test_dnf" = "mono" ]; then
			echo "\033[32m[+] Opening project...\033[32m"
			mono $app_name
		else
			echo "\033[34m [+] Detected \033[4m dnf \033[24m package manager \033[34m"
			echo "\033[34m [+] Process is starting... \033[34m"
			echo "\033[34m [+] Testing connection... \033[34m"
			connection_test_dnf=$(echo "$check_connection_method")
				if [ "$connection_test_dnf" -eq 2 ]; then
					echo "\033[31m [-] Error: connection refused. Network unavailable. \033[31m"
					echo "\033[31m [-] Installing error \033[31m"
				else
					echo "\033[32m [+] Connection: ok \033[32m"
					echo "\033[32m [+] Installing mono-complete, please wait...\033[32m"
					rpm --import "https://keyserver.ubuntu.com/pks/lookup?op=get&search=0x3FA7E0328081BFF6A14DA29AA6A19B38D3D831EF" >/dev/null 2>&1
					su -c 'curl https://download.mono-project.com/repo/centos8-stable.repo | tee /etc/yum.repos.d/mono-centos8-stable.repo' >/dev/null 2>&1
					dnf update -y >/dev/null 2>&1
					dnf install mono-complete -y >/dev/null 2>&1
					mono_second_test_dnf=$(echo $find_mono)
						if [ "$mono_second_test_dnf" != "mono" ]; then
							echo "\033[31m [-] Installing error \033[41m"
							echo "\033[36m [?] If you can not install mono-complete automatically, please visit officall site: \033[33;4m "$officall_site" \033[43;24m \033[46m"
						else
							echo "\033[32m [+] installation completed successfully \033[32m"
							mono $app_name
						fi
				fi
		fi
fi

# По поводу всех ошибок или неисправностей обращайтесь к разработчику этого скрипта - @became_you
